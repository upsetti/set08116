Computer Graphics Coursework!

Camera Controls:
	1 / 2 / 3 cycles through the target cameras (switches off free cam if that was the current)
	4 switches to free camera
		Standard WASD movement
		Mouse for orientation

Updates since Demo:
	Added normal-mapping (to the moon)
	Changed the moon's position to its original one when first implemented
	Added transform hierarchy to the toruses (tori?)
	
Shadows
	Could not for the life of me get them to work, unfortunately

Report
	Could not get the letex stuff working so submitted as PDF so the content is still there